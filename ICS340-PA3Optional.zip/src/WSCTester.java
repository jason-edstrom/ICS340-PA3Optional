/**
 * Created with IntelliJ IDEA.
 * User: Jason
 * Date: 3/4/13
 * Time: 7:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class WSCTester {

    public static void main (String args[]){
        WordSearcherCollection WSCtest = new WordSearcherCollection("words.txt", "Theme65");
    }
}
